"use strict";
// Footer data.

export default {
    data: () => ({
        links: [
            {
                title: 'Home',
                src: '#'
            },
            {
                title: 'About',
                src: 'About'
            },
            {
                title: 'Projects',
                src: 'https://people.rit.edu/iae2784/330/'
            }
        ]
    }),
}
